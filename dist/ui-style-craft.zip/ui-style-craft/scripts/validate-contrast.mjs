#!/usr/bin/env node
/**
 * validate-contrast.mjs — WCAG contrast gate for a token set.
 *
 * Reads tokens.json, enumerates every semantic text/background pairing, and
 * reports WCAG AA compliance. Exits 1 if any pairing fails (CI-friendly).
 *
 * Usage:
 *   node validate-contrast.mjs --tokens tokens.json --level AA
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { hexToHsl, hslToHex, contrastRatio } from '../lib/color.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function arg(name, def) {
  const i = process.argv.indexOf(name);
  return i !== -1 && process.argv[i + 1] ? process.argv[i + 1] : def;
}
const tokensPath = arg('--tokens', path.resolve(__dirname, '..', 'assets', 'default-tokens.json'));
const level = arg('--level', 'AA');
const threshold = level === 'AAA' ? 7 : 4.5;

if (!fs.existsSync(tokensPath)) { console.error(`tokens file not found: ${tokensPath}`); process.exit(2); }
const tk = JSON.parse(fs.readFileSync(tokensPath, 'utf8'));
const sem = tk.color.semantic;

const pairs = [
  ['text-primary', ['bg', 'surface', 'surface-2']],
  ['text-secondary', ['bg', 'surface', 'surface-2']],
  ['text-muted', ['bg', 'surface', 'surface-2']],
  ['primary-fg', ['primary']],
];

// Suggest an adjusted text color that meets the threshold on the given bg.
function suggest(textHex, bgHex) {
  const hsl = hexToHsl(textHex);
  const bgLum = contrastRatio(textHex, bgHex) != null ? null : null;
  void bgLum;
  const bgIsLighter = contrastRatio('#000000', bgHex) < contrastRatio('#ffffff', bgHex);
  let lo = 0, hi = 100;
  for (let i = 0; i < 24; i++) {
    const mid = (lo + hi) / 2;
    const cand = hslToHex(hsl.h, hsl.s, mid);
    const ok = contrastRatio(cand, bgHex) >= threshold;
    if (bgIsLighter) { if (ok) hi = mid; else lo = mid; }
    else { if (ok) lo = mid; else hi = mid; }
  }
  return hslToHex(hsl.h, hsl.s, (lo + hi) / 2);
}

const fails = [];
console.log(`\nWCAG ${level} contrast check (threshold ≥ ${threshold}:1)\n`);
for (const [textKey, bgs] of pairs) {
  const textHex = sem[textKey];
  for (const bgKey of bgs) {
    const bgHex = sem[bgKey];
    const ratio = contrastRatio(textHex, bgHex);
    const ok = ratio >= threshold;
    const tag = ok ? 'PASS' : 'FAIL';
    let line = `  [${tag}] ${textKey.padEnd(14)} on ${bgKey.padEnd(10)} ${ratio.toFixed(2)}:1`;
    if (!ok) {
      const fix = suggest(textHex, bgHex);
      line += `  → 建议调整为 ${fix}`;
      fails.push({ textKey, bgKey, ratio });
    }
    console.log(line);
  }
}

console.log('');
if (fails.length === 0) {
  console.log('✓ All semantic text/background pairings meet WCAG ' + level + '.');
  process.exit(0);
} else {
  console.log(`✗ ${fails.length} pairing(s) below WCAG ${level}. Fix the tokens and re-run.`);
  process.exit(1);
}
